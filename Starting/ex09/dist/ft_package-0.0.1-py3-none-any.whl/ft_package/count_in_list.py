def count_in_list(lst, item):
    """Return how many times item appears in lst."""
    return lst.count(item)
